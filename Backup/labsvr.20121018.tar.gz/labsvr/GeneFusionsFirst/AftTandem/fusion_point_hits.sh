perl fusion_point_hits.pl  fusion_point_1 0 >fusion_point_1_0
perl fusion_point_hits.pl  fusion_point_1 1 >fusion_point_1_1
perl fusion_point_hits.pl  fusion_point_1 2 >fusion_point_1_2
perl fusion_point_hits.pl  fusion_point_1 3 >fusion_point_1_3


perl fusion_point_hits.pl  fusion_point_2 0 >fusion_point_2_0
perl fusion_point_hits.pl  fusion_point_2 1 >fusion_point_2_1
perl fusion_point_hits.pl  fusion_point_2 2 >fusion_point_2_2
perl fusion_point_hits.pl  fusion_point_2 3 >fusion_point_2_3

perl fusion_point_hits.pl  fusion_point_3 0 >fusion_point_3_0
perl fusion_point_hits.pl  fusion_point_3 1 >fusion_point_3_1
perl fusion_point_hits.pl  fusion_point_3 2 >fusion_point_3_2
perl fusion_point_hits.pl  fusion_point_3 3 >fusion_point_3_3

perl fusion_point_hits.pl  fusion_point_4 0 >fusion_point_4_0
perl fusion_point_hits.pl  fusion_point_4 1 >fusion_point_4_1
perl fusion_point_hits.pl  fusion_point_4 2 >fusion_point_4_2
perl fusion_point_hits.pl  fusion_point_4 3 >fusion_point_4_3



perl fusion_point_hits.pl splicing_point_1 0 >splicing_point_1_0
perl fusion_point_hits.pl splicing_point_1 1 >splicing_point_1_1
perl fusion_point_hits.pl splicing_point_1 2 >splicing_point_1_2
perl fusion_point_hits.pl splicing_point_1 3 >splicing_point_1_3

perl fusion_point_hits.pl splicing_point_2 0 >splicing_point_2_0
perl fusion_point_hits.pl splicing_point_2 1 >splicing_point_2_1
perl fusion_point_hits.pl splicing_point_2 2 >splicing_point_2_2
perl fusion_point_hits.pl splicing_point_2 3 >splicing_point_2_3


perl fusion_point_hits.pl splicing_point_3 0 >splicing_point_3_0
perl fusion_point_hits.pl splicing_point_3 1 >splicing_point_3_1
perl fusion_point_hits.pl splicing_point_3 2 >splicing_point_3_2
perl fusion_point_hits.pl splicing_point_3 3 >splicing_point_3_3

perl fusion_point_hits.pl splicing_point_4 0 >splicing_point_4_0
perl fusion_point_hits.pl splicing_point_4 1 >splicing_point_4_1
perl fusion_point_hits.pl splicing_point_4 2 >splicing_point_4_2
perl fusion_point_hits.pl splicing_point_4 3 >splicing_point_4_3




