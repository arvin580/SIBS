#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Human
#makeblastdb -dbtype nucl -in ucsc.hg19.fasta


#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Mouse
#makeblastdb -dbtype nucl -in ucsc.mouse.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Rat
#makeblastdb -dbtype nucl -in ucsc.rat.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Chicken
#makeblastdb -dbtype nucl -in ucsc.chicken.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Chimpanzee
#makeblastdb -dbtype nucl -in ucsc.chimpanzee.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Cow
#makeblastdb -dbtype nucl -in ucsc.cow.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Dog
#makeblastdb -dbtype nucl -in ucsc.dog.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Elephant
#makeblastdb -dbtype nucl -in ucsc.elephant.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Fugu
#makeblastdb -dbtype nucl -in ucsc.fugu.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Opossum
#makeblastdb -dbtype nucl -in ucsc.opossum.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Platypus
#makeblastdb -dbtype nucl -in ucsc.platypus.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Tetraodon
#makeblastdb -dbtype nucl -in ucsc.tetraodon.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Xenopus
#makeblastdb -dbtype nucl -in ucsc.xenopus.fasta
#
#cd  /netshare1/home1/people/hansun/Project/lncRNA/GenomeSeq/Zebrafish
#makeblastdb -dbtype nucl -in ucsc.zebrafish.fasta


cd /netshare1/home1/people/hansun/Data/VirusesGenome 
makeblastdb -dbtype nucl -in VirusesGenome.fasta
