cd /netshare1/home1/people/hansun/Data/hg19_refGene
/netshare1/home1/people/hansun/MySoft/Python/EPDfree/bin/ipython refGene2.py 
