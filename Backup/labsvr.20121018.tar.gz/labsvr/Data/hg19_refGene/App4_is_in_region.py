from RefGene_class import *
a=RefGene()
#a.is_in_region('chr6',57000000,58000000)
a.is_in_region('chr8',0,45600000)
