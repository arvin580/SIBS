cd /netshare1/home1/people/hansun/GeneFusionsFinal/Translate
#perl translate.pl exon_fusion exon_fusion_peptide
#perl translate.pl splicing_exon  splicing_exon_peptide
#perl exon_fusion_peptide_qc.pl
perl splicing_exon_peptide_qc.pl
