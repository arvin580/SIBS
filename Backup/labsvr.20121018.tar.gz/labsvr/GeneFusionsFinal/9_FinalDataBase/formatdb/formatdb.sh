cd /netshare1/home1/people/hansun/GeneFusionsFinal/FinalDataBase/formatdb
formatdb -i fusion_splicing_uniprot_ensembl_contaminated_final 
