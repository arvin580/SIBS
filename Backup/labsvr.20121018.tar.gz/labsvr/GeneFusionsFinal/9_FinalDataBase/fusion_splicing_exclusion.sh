#!/bin/bash

cd /netshare1/home1/people/hansun/GeneFusionsFinal/FinalDataBase
perl fusion_splicing_exclusion.pl /netshare1/home1/people/hansun/GeneFusionsFinal/Pep2DNA/fusion_splicing_point_3_2_complete_c fusion_splicing_uniprot_ensembl_contaminated_final2
