import os
os.system('cat Tandem.Omssa.FDR.pep.genefusions.final.pos.3.3.spec2.num.both Tandem.Omssa.FDR.pep.splicing.final.pos.3.3.spec2.num.both >Tandem.Omssa.FDR.pep.genefusions.splicing.final.pos.3.3.spec2.num.both ')
os.system('cat Tandem.Omssa.FDR.pep.genefusions.final.pos.3.3.spec2.num.tandem Tandem.Omssa.FDR.pep.splicing.final.pos.3.3.spec2.num.tandem >Tandem.Omssa.FDR.pep.genefusions.splicing.final.pos.3.3.spec2.num.tandem ')
os.system('cat Tandem.Omssa.FDR.pep.genefusions.final.pos.3.3.spec2.num.omssa Tandem.Omssa.FDR.pep.splicing.final.pos.3.3.spec2.num.omssa >Tandem.Omssa.FDR.pep.genefusions.splicing.final.pos.3.3.spec2.num.omssa ')
