#!/bin/bash
cd /netshare1/home1/people/hansun/GeneFusionsFinal/SpecPep
python spectrum_peptide.py /netshare1/home1/people/hansun/GeneFusionsFinal/Tandem/output /netshare1/home1/people/hansun/GeneFusionsFinal/Tandem2/output spectrum_peptide_map spectrum_peptide_map2 
