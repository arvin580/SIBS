cd /netshare1/home1/people/hansun/GeneFusionsFinal/Pep2DNA

perl pep2dna_4.pl fusion_point_3_2_complete_c_title
perl pep2dna_4.pl splicing_point_3_2_complete_c_title
