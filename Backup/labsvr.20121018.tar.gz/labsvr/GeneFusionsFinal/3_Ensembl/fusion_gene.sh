cd /netshare1/home1/people/hansun/GeneFusionsFinal/Ensembl
#perl fusion_gene.pl fusion_gene_unique_chimerdb
#perl fusion_gene.pl fusion_gene_unique_CancerGeneCensus
perl fusion_gene.pl fusion_gene_unique

