#!/usr/bin/env python
print('hahaha')
