R=r'''

a=c(12,3,4)
print(a)

'''
from RscriptClass import Rscript
Rscript(R)
