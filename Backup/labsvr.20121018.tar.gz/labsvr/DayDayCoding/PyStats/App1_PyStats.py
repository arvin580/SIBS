from PyStatsClass import * 
ps=PyStats()
a=ps.fisher_test([100,6,40,300])
print(a)

