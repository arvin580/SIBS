cd /netshare1/home1/people/hansun/DayDayCoding/dna2protein 
python App1_RefGene.py >dna_protein_out3 2>dna_protein_out4
