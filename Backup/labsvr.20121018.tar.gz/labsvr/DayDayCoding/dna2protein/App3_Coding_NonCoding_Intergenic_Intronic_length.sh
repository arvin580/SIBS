cd /netshare1/home1/people/hansun/DayDayCoding/dna2protein 
python  App3_Coding_NonCoding_Intergenic_Intronic_length.py
