python discovery.py raw.snp1a.vcf
python discovery.py raw.snp2a.vcf
python discovery.py raw.snp3a.vcf
python discovery.py raw.snp4a.vcf
python discovery.py raw.snp5a.vcf
python discovery.py raw.snp6a.vcf
python discovery.py raw.snp7a.vcf
python discovery.py raw.snp8a.vcf
