cd /netshare1/home1/szzhongxin/proj1/hansun/mapping2/2A

sam2pindel 2A.sam  2A.pindel 500 2a 0 
