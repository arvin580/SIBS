cd /netshare1/home1/szzhongxin/proj1/hansun/mapping2/2A
samtools view -h 2A.bam >2A.sam
