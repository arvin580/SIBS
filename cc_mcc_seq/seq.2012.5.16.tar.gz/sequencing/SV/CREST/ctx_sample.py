###  python ctx_sample.py  ...

import sys
dict1=dict()

for file in sys.argv[1:] :
    inFile1=open(file,'r')
    for line in inFile1 :
        fields=line.split('\t')
        if fields[3]!='' :
            for gene in fields[3].split(':'):
                dict1.setdefault(gene,[0])
                dict1[gene][0]+=1

    inFile1.close()

ouFile1=open('ctx_sample1','w')
ouFile2=open('ctx_sample2','w')

for item in sorted(dict1.items(),key=lambda x:x[0]):
    ouFile2.write(item[0]+'\t'+str(item[1][0])+'\n')
for item in sorted(dict1.items(),key=lambda x:x[1],reverse=True):
    ouFile1.write(item[0]+'\t'+str(item[1][0])+'\n')

ouFile1.close()
ouFile2.close()

   


