''' python 8p.py 1 45600000 '''


