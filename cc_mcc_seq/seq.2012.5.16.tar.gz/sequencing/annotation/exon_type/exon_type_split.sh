#cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/exon_type/snpindel_snp3030
#python ../exon_type_split.py snpindel_snp3030_raw.snp.recalibrated.annovar.exonic_variant_function

cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/exon_type/snpindel_indel3030
python ../exon_type_split.py snpindel_indel3030_raw.indel.recalibrated.annovar.exonic_variant_function

#cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/exon_type/snpindel2_snp3030
#python ../exon_type_split.py snpindel2_snp3030_raw.snp.recalibrated.annovar.exonic_variant_function

cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/exon_type/snpindel2_indel3030
python ../exon_type_split.py snpindel2_indel3030_raw.indel.recalibrated.annovar.exonic_variant_function
