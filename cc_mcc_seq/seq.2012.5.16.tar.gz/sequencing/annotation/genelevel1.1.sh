cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/snpindel_indel3030
python ../genelevel1.1.py snpindel_indel3030_raw.indel.recalibrated.annovar.exonic_variant_function
cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/snpindel2_indel3030
python ../genelevel1.1.py snpindel2_indel3030_raw.indel.recalibrated.annovar.exonic_variant_function
