#cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/snpindel_snp3030
#python ../distribution.py snpindel_snp3030_raw.snp.recalibrated.annovar.variant_function

cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/snpindel_indel3030
python ../distribution.py snpindel_indel3030_raw.indel.recalibrated.annovar.variant_function


#cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/snpindel2_snp3030
#python ../distribution.py snpindel2_snp3030_raw.snp.recalibrated.annovar.variant_function

cd /netshare1/home1/szzhongxin/proj1/hansun/annotation/snpindel2_indel3030
python ../distribution.py snpindel2_indel3030_raw.indel.recalibrated.annovar.variant_function

