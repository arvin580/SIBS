cd /netshare1/home1/szzhongxin/proj1/hansun/Results/snp

python 18_3_sum_snp.type.py
